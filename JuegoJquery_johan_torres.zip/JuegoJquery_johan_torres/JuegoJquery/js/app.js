$(function Iniciarjuego(){

/////////////////////////////
////////////////////////////
//Variables del sistema
var eliminar=0,nuevosDulces=0,tiempo=0,rastreonuevosDulces=0, maximo=0,matriz=0,intervalo=0,rastreoHorizontal=0,score=0,
i=0,rastreoVertical=0,contadorTotal=0,espera=0,movimientos=0,minutos=2,segundos=0;


//valores que se restableceran al precionar reiniciar
function variblesJuego(){
   intervalo=0,score=0,i=0,minutos=2,segundos=0,movimientos=0;
   $(".panel-score").css("width","26%");
   $(".panel-tablero").show();
  $(".time").show();
   $("#movimientos-text").html("0");
   $("#score-text").html("0");

}
//Matricez del tablero
var leercolumnas=["","","","","","",""];
var lenrest=["","","","","","",""];
/////////////////////////////////////////////
/////////////////////////////////////////////

// Desencadena el parpadeo en el título
inicioProceso();

function inicioProceso()
{
  cuentav=0;
  $( ".main-titulo" ).animate(
   {

   }, 2000, function()
   {
      inicioColor();
   });
}
//Cambia el color Original del titulo y llama la funcion del color original
function inicioColor()
{

 $( ".main-titulo" ).animate(
   {
     color: "White"
    }, 2000, function() {
       SegundoColor();
   });

 }
//vuelve al color original y llama al inicio de ciclo
function SegundoColor(){

   $( ".main-titulo" ).animate({

    color: "yellow"

     }, 2000, function() {
       blanco();
     });


}

//Inicio de ciclo cambia de amarillo a blanco y llama a la funcion de cambia a mararillo
function blanco(){
//validar cuantos cambios ha tenido el ciclo para reiniciarlo
  if (cuentav <=2) {
   cuentav++;

    $( ".main-titulo" ).animate({

      color: "White",

    }, 500, function() {
     amarillo();
    });
//Reinicia el proceso
 }else {
  inicioProceso();
  }
}
//Ciclo cambio a color amarillo
function amarillo(){
   $( ".main-titulo" ).animate({
//opacity: 0.25,
    color: "yellow",

   }, 500, function() {
    blanco();
});
}


//Hasta aquí el efecto del Título
///////////////////////////////////////////
///////////////////////////////////////////



// Boton Star

$(".btn-reinicio").on("click",function(){
  variblesJuego();
  $(this).html("Reiniciar");
  validacionesdeTiempo(intervalo);
  validacionesdeTiempo(eliminar);
  validacionesdeTiempo(nuevosDulces);
  validacionesdeTiempo(tiempo);
	eliminarImagenes();
	intervalo=setInterval(function(){
		CragarDulcess()
	},400);
	tiempo=setInterval(function(){
		timer()
	},1000);
});
////////////////////////////////////////////
/////////////////////////////////////////////


//Funciones del tablero

// Función para borrar imagenes del tablero

function eliminarImagenes(){
	for(var j=1;j<8;j++){
		$(".col-"+j).children("img").detach();}
};

// Función para restablecer el tablero
function restablecerPanelScore(){
	$( ".panel-score" ).animate({width:'100%'},3000);
};

//  Comenzar el Juego con dulces

function CragarDulcess(){
	i++;
	var num=0,imagen=0;
	$(".elemento").draggable({disabled:true});
	if(i<8){
		for(var j=1;j<8;j++){
  var resultado = $(".col-"+j).children("img:nthchild("+i+")").html();

			if($(".col-"+j).children("img:nth-child("+i+")").html()==null){
				num=Math.floor(Math.random()*4)+1;
				imagen="image/"+num+".png";
				$(".col-"+j).prepend("<img src="+imagen+" class='elemento'/>");
			}}}
	if(i==8){
     validacionesdeTiempo(intervalo);
	    eliminar=setInterval(function(){
		   eliminarConinsidencias()
	},150);}
};

// eliminar los Dulces cuando hayan coincidencias

function eliminarConinsidencias(){
	matriz=0;
  rastreoHorizontal=Horizontal();
	rastreoVertical=vertical();
	for(var j=1;j<8;j++){
		matriz=matriz+$(".col-"+j).children().length;}

	//Condicional si no encuentra 3 dulces o más, llamamos a la función para volver a completar el juego

	if(rastreoHorizontal==0 && rastreoVertical==0 && matriz!=49){
	validacionesdeTiempo(eliminar);
		rastreonuevosDulces=0;
		nuevosDulces=setInterval(function(){
			dulcesNuevos()
		},600);}

	if(rastreoHorizontal==1||rastreoVertical==1){
		$(".elemento").draggable({disabled:true});
		$("div[class^='col']").css("justify-content","flex-end");
		$(".activo").hide("pulsate",1000,function(){
			var scoretmp=$(".activo").length;
			$(".activo").remove("img");
			score=score+scoretmp*10;
			$("#score-text").html(score);//Cambiamos la puntuación
		});
	}
	if(rastreoHorizontal==0 && rastreoVertical==0 && matriz==49){
    var columna = $('[class^="col-"]');

		$(".elemento").draggable({
			disabled:false,
			containment:".panel-tablero",revert:true,revertDuration:0,
			snap:".elemento",snapMode:"inner",snapTolerance:40,
			start:function(event,ui){
				movimientos=movimientos+1;
				$("#movimientos-text").html(movimientos);}
		});
	}
	$(".elemento").droppable({
		drop:function (event,ui){
			var dropped=ui.draggable;
			var droppedOn=this;
			espera=0;
			do{
				espera=dropped.swap($(droppedOn));}
			while(espera==0);
			rastreoHorizontal=Horizontal();
			rastreoVertical=vertical();
			if(rastreoHorizontal==0 && rastreoVertical==0){
				dropped.swap($(droppedOn));}
			if(rastreoHorizontal==1 || rastreoVertical==1){
				validacionesdeTiempo(nuevosDulces);
				validacionesdeTiempo(eliminar);
				eliminar=setInterval(function(){
					eliminarConinsidencias()
				},150);}},
	});
};

// intercambio de dulces

jQuery.fn.swap=function(b){
	b=jQuery(b)[0];
	var a=this[0];
	var t=a.parentNode.insertBefore(document.createTextNode(''),a);
	b.parentNode.insertBefore(a,b);
	t.parentNode.insertBefore(b,t);
	t.parentNode.removeChild(t);
	return this;
};

// Función para crear nuevos dulces

function dulcesNuevos(){
	$(".elemento").draggable({disabled:true});
	$("div[class^='col']").css("justify-content","flex-start")
	for(var j=1;j<8;j++){
		leercolumnas[j-1]=$(".col-"+j).children().length;}
	if(rastreonuevosDulces==0){
		for(var j=0;j<7;j++){
			lenrest[j]=(7-leercolumnas[j]);}
		maximo=Math.max.apply(null,lenrest);
		contadorTotal=maximo;}
	if(maximo!=0){
		if(rastreonuevosDulces==1){
			for(var j=1;j<8;j++){
				if(contadorTotal>(maximo-lenrest[j-1])){
					$(".col-"+j).children("img:nth-child("+(lenrest[j-1])+")").remove("img");}}
		}
		if(rastreonuevosDulces==0){
			rastreonuevosDulces=1;
			for(var k=1;k<8;k++){
				for(var j=0;j<(lenrest[k-1]-1);j++){
					$(".col-"+k).prepend("<img src='' class='elemento' style='visibility:hidden'/>");}}
		}
		for(var j=1;j<8;j++){
			if(contadorTotal>(maximo-lenrest[j-1])){
				num=Math.floor(Math.random()*4)+1;
				imagen="image/"+num+".png";
				$(".col-"+j).prepend("<img src="+imagen+" class='elemento'/>");}
		}
	}
	if(contadorTotal==1){
		validacionesdeTiempo(nuevosDulces);
		eliminar=setInterval(function(){
			eliminarConinsidencias()
		},150);
	}
	contadorTotal=contadorTotal-1;
};

// Función para la busqueda en columnas  de dulces

function Horizontal(){
	var busHori=0;
	for(var j=1;j<8;j++){
		for(var k=1;k<6;k++){
			var res1=$(".col-"+k).children("img:nth-last-child("+j+")").attr("src");
			var res2=$(".col-"+(k+1)).children("img:nth-last-child("+j+")").attr("src");
			var res3=$(".col-"+(k+2)).children("img:nth-last-child("+j+")").attr("src");
			if((res1==res2) && (res2==res3) && (res1!=null) && (res2!=null) && (res3!=null)){
				$(".col-"+k).children("img:nth-last-child("+(j)+")").attr("class","elemento activo");
				$(".col-"+(k+1)).children("img:nth-last-child("+(j)+")").attr("class","elemento activo");
				$(".col-"+(k+2)).children("img:nth-last-child("+(j)+")").attr("class","elemento activo");
				busHori=1;
			}
		}
	}
	return busHori;
};

// Función para la busqueda en filas de dulces

function vertical(){
	var busVerti=0;
	for(var l=1;l<6;l++){
		for(var k=1;k<8;k++){
			var res1=$(".col-"+k).children("img:nth-child("+l+")").attr("src");
			var res2=$(".col-"+k).children("img:nth-child("+(l+1)+")").attr("src");
			var res3=$(".col-"+k).children("img:nth-child("+(l+2)+")").attr("src");
			if((res1==res2) && (res2==res3) && (res1!=null) && (res2!=null) && (res3!=null)){
				$(".col-"+k).children("img:nth-child("+(l)+")").attr("class","elemento activo");
				$(".col-"+k).children("img:nth-child("+(l+1)+")").attr("class","elemento activo");
				$(".col-"+k).children("img:nth-child("+(l+2)+")").attr("class","elemento activo");
				busVerti=1;
			}
		}
	}
	return busVerti;
};
///////////////////////////////////////
//////////////////////////////////////

// controla el tiempo de la partida

function timer(){
	if(segundos!=0){
		segundos=segundos-1;}
	if(segundos==0){
		if(minutos==0){
			validacionesdeTiempo(eliminar);
			validacionesdeTiempo(nuevosDulces);
			validacionesdeTiempo(intervalo);
			validacionesdeTiempo(tiempo);
			$(".panel-tablero").hide("drop","slow",restablecerPanelScore);
			$(".time").hide();}
		segundos=59;
		minutos=minutos-1;}
	$("#timer").html("0"+minutos+":"+segundos);
};
function validacionesdeTiempo(t){
clearInterval(t);

return t;

}
})
